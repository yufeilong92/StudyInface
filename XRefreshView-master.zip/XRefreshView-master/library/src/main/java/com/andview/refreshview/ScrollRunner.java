package com.andview.refreshview;

/**
 * Created by huxq17 on 2016/12/15.
 */

public abstract class ScrollRunner implements Runnable {
    public boolean isStopLoadMore = false;
}
